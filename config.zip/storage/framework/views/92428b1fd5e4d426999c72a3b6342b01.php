

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="container-fluid">

            <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800 text-center mb-3">Detail Transaksi</h1>

            <!-- DataTales Example -->
            <div class="card shadow-sm mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-danger text-center">Detail Transaksi</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <a href="<?php echo e(url(URL::previous())); ?>" class="btn btn-danger mb-3">Kembali</a>
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead class="bg-danger text-light">
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama Product</th>
                                    <th>Harga</th>
                                    <th>QTY</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="vertical-align: middle"><?php echo e($loop->iteration); ?></td>
                                        <td style="vertical-align: middle"><?php echo e($p->nama_product); ?></td>
                                        <td style="vertical-align: middle"><?php echo e(rupiah($p->harga)); ?></td>
                                        <td style="vertical-align: middle"><?php echo e($p->qty); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mywork\laporan-cupang\resources\views/transaksi/detail.blade.php ENDPATH**/ ?>