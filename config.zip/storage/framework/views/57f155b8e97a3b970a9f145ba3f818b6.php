

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="container-fluid">

            <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800 text-center mb-3">Data Transaksi</h1>

            <!-- DataTales Example -->
            <div class="card shadow-sm mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-danger text-center">Transaksi</h6>
                </div>
                <div class="card-body">
                    <div class="alert alert-info d-flex justify-content-between" role="alert">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <div>
                            TOTAL PEMASUKAN : <span class="fw-bold text-decoration-underline text-primary"><?php echo e(rupiah($pemasukan)); ?></span>
                        </div>
                        <i class="fa-solid fa-circle-exclamation"></i>
                      </div>
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead class="bg-danger text-light">
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama Pembeli</th>
                                    <th>Ongkir</th>
                                    <th>Id Pesanan</th>
                                    <th>Status</th>
                                    <th>Alamat Pembeli</th>
                                    <th>Total Bayar</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="vertical-align: middle"><?php echo e($loop->iteration); ?></td>
                                        <td style="vertical-align: middle"><?php echo e($p->nama_pembeli); ?></td>
                                        <td style="vertical-align: middle"><?php echo e(rupiah($p->ongkir)); ?></td>
                                        <td style="vertical-align: middle"><?php echo e($p->id_pesanan); ?></td>
                                        <td style="vertical-align: middle" class="text-success"><?php echo e($p->status); ?></td>
                                        <td style="vertical-align: middle"><?php echo e($p->alamat_pembeli); ?></td>
                                        <td style="vertical-align: middle"><?php echo e(rupiah($p->total_bayar)); ?></td>
                                        <td style="vertical-align: middle">
                                            <a href="<?php echo e(url('/dashboard/transaksi/detail/'.$p->id)); ?>" class="btn btn-primary"><i class="fa-solid fa-eye"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($transaksi->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mywork\laporan-cupang\resources\views/transaksi/index.blade.php ENDPATH**/ ?>