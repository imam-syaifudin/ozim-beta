

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="container-fluid">

            <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800 text-center mb-3">Cart Anda</h1>

            <!-- DataTales Example -->
            <div class="card shadow-sm mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-danger text-center">Cart</h6>
                </div>
                <div class="card-body">
                    <?php if(Session::has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('error')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <a href="<?php echo e(url('/ongkir')); ?>" class="btn btn-success mb-2 d-block">CheckOut</a>
                    <?php if($cart !== null): ?>
                        <div class="alert alert-primary text-center" role="alert">
                            TOTAL BAYAR : <span class="fw-bold"><?php echo e(rupiah($totalBayar)); ?> ( Belum termasuk ongkir )</span>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead class="bg-danger text-light">
                                <tr class="text-center">
                                    <th>No</th>
                                    <th>Nama Product</th>
                                    <th>Stok</th>
                                    <th>Harga Product</th>
                                    <th>Total Harga</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="vertical-align: middle"><?php echo e($loop->iteration); ?></td>
                                        <td style="vertical-align: middle"><?php echo e($c->product->name); ?></td>
                                        <td style="vertical-align: middle"><?php echo e($c->stok); ?></td>
                                        <td style="vertical-align: middle"><?php echo e(rupiah($c->product->harga)); ?></td>
                                        <td style="vertical-align: middle"><?php echo e(rupiah($c->stok * $c->product->harga)); ?></td>
                                        <td style="vertical-align: middle">
                                            <a href="<?php echo e(route('cart.edit', $c->id)); ?>" class="btn btn-primary">Edit</a>
                                            <form action="<?php echo e(route('cart.destroy', $c->id)); ?>" class="d-inline"
                                                method="POST">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mywork\laporan-cupang\resources\views/cart/index.blade.php ENDPATH**/ ?>