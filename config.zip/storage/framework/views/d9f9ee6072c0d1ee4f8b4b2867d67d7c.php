

<?php $__env->startSection('main'); ?>
    <div class="container">

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-danger">Form Tambah Product</h6>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('profile.edit',$user->id)); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Nama : </label>
                        <input type="text" class="form-control" id="exampleFormControlInput1"
                            name="name" value="<?php echo e($user->name); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Username : </label>
                        <input type="text" class="form-control" id="gambar" name="username" value="<?php echo e($user->username); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Email : </label>
                        <input type="email" class="form-control" id="exampleFormControlInput1" name="email"
                        value="<?php echo e($user->email); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Password : ( Kosongkan jika tidak ingin diganti )</label>
                        <input type="password" class="form-control" id="exampleFormControlInput1" name="password"
                            >
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Telp</label>
                        <input type="text" class="form-control" id="exampleFormControlInput1" name="telp"
                        value="<?php echo e($user->telp); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">Alamat</label>
                        <input type="text" class="form-control" id="exampleFormControlInput1" name="alamat"
                        value="<?php echo e($user->alamat); ?>">
                    </div>


                    <label for="exampleFormControlInput1" class="form-label">Jenis Kelamin : </label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="kelamin" value="laki"
                        id="flexRadioDefault1" <?php if( $user->kelamin == 'laki'): ?> checked <?php endif; ?>>
                        <label class="form-check-label" for="flexRadioDefault1">
                            Laki - laki
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="kelamin" value="perempuan"
                            id="flexRadioDefault2" <?php if( $user->kelamin == 'perempuan'): ?> checked <?php endif; ?>>
                        <label class="form-check-label" for="flexRadioDefault2">
                            Perempuan
                        </label>
                    </div>
                      <button type="submit" class="btn btn-danger mt-2">Edit Profile</button>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mywork\laporan-cupang\resources\views/dashboard/profile.blade.php ENDPATH**/ ?>