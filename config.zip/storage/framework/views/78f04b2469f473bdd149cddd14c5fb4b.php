

<?php $__env->startSection('main'); ?>
    <div class="container">
        <main>

            <section class="text-center container">
                <div class="row py-lg-5">
                    <div class="col-lg-6 col-md-8 mx-auto">
                        <h1 class="fw-light">Product Kami</h1>
                    </div>
                </div>
            </section>

            <div class="album py-5">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8">
                            <form action="<?php echo e(url('/product/cari')); ?>" method="GET">
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" placeholder="Cari Product"
                                        aria-label="Recipient's username" aria-describedby="basic-addon2" name="keyword"
                                        value="<?php echo e(request('keyword')); ?>">
                                    <button class="input-group-text btn btn-danger" type="submit" id="basic-addon2">Cari</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-lg-12">
                            <?php echo e($product->links()); ?>

                        </div>
                    </div>
                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col">
                                <div class="card shadow-sm">
                                    <img src="<?php echo e(asset('storage/' . $pro->gambar)); ?>"
                                        class="bd-placeholder-img card-img-top" width="100%" height="225"
                                        alt="">
                                    <div class="card-body">
                                        <p><strong><?php echo e($pro->name); ?></strong></p>
                                        <p class="card-text"><?php echo e(Str::limit($pro->deskripsi, 120)); ?></p>
                                        <p class="fw-bold"><?php echo e(rupiah($pro->harga)); ?></p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="btn-group">
                                                <a href="<?php echo e(route('product.show.index', $pro->id)); ?>"
                                                    class="btn btn-sm btn-primary">View</a>
                                            </div>
                                            <small
                                                class="text-muted"><?php echo e($pro->kategori == 'ikancupang' ? 'Ikan Cupang' : 'Alat Perawatan'); ?></small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row mt-3">
                        <div class="col-lg-12">
                            <?php echo e($product->links()); ?>

                        </div>
                    </div>
                </div>
            </div>

        </main>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mywork\laporan-cupang\resources\views/index.blade.php ENDPATH**/ ?>