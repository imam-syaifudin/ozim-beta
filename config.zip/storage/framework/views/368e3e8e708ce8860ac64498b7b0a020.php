

<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="card shadow-sm mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-danger text-center">Profile</h6>
            </div>
            <div class="card-body p-5">
                <div class="row">
                    <div class="col-lg-6">
                        <img class="img-profile rounded-circle img-thumbnail shadow"
                                    src="<?php echo e(asset('sbadmin/img/undraw_profile.svg')); ?>" width="400" height="400">
                    </div>
                    <div class="col-lg-6 mt-4 text-center   ">
                        <h5>Nama : <?php echo e(auth()->user()->name); ?></h5>
                        <hr>
                        <h5>User Name : <?php echo e(auth()->user()->username); ?></h5>
                        <hr>
                        <h5>Email : <?php echo e(auth()->user()->email); ?></h5>
                        <hr>
                        <h5>Kelamin : <?php echo e(auth()->user()->kelamin); ?></h5>
                        <hr>
                        <h5>Telpon : <?php echo e(auth()->user()->telp); ?></h5>
                        <hr>
                        <h5>Alamat : <?php echo e(auth()->user()->alamat); ?></h5>
                        <hr>
                        <h5>Role : <?php echo e(auth()->user()->role); ?></h5>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 mt-3">
                        <a href="<?php echo e(route('profile',auth()->user()->id)); ?>" class="btn btn-outline-success d-block">Edit Profile</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\mywork\laporan-cupang\resources\views/dashboard/index.blade.php ENDPATH**/ ?>